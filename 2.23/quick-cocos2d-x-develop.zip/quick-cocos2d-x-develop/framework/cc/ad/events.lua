
local events = {}

events.RECEIVED = "RECEIVED"
events.PRESENT  = "PRESENT"
events.DISMISS  = "DISMISS"
events.FAILED   = "FAILED"

return events
