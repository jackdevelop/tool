local BuildingProperties = {}

local defines = {}

local building = {
    maxHp             = 1800, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP001"] = building

----------------------

local building = {
    maxHp             = 1800, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP002"] = building

----------------------

local building = {
    maxHp             = 2000, -- 最大 HP
    maxArmor          = 20,    -- 最大装甲
}
defines["BuildingP003"] = building

----------------------

local building = {
    maxHp             = 1800, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP004"] = building

----------------------

local building = {
    maxHp             = 2500, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP005"] = building

----------------------

local building = {
    maxHp             = 2500, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP006"] = building

----------------------

local building = {
    maxHp             = 2500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP007"] = building

----------------------

local building = {
    maxHp             = 2500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP008"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP009"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP010"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP011"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP012"] = building

----------------------

local building = {
    maxHp             = 10000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP013"] = building

----------------------

local building = {
    maxHp             = 10000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP014"] = building

----------------------
local building = {
    maxHp             = 13600, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP015"] = building

----------------------

local building = {
    maxHp             = 13600, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP016"] = building

----------------------

local building = {
    maxHp             = 20000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP017"] = building

----------------------

local building = {
    maxHp             = 20000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP018"] = building

----------------------

local building = {
    maxHp             = 26000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP019"] = building

----------------------

local building = {
    maxHp             = 26000, -- 最大 HP
    maxArmor          = 50,    -- 最大装甲
}
defines["BuildingP020"] = building

----------------------

local building = {
    maxHp             = 30000, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP021"] = building

----------------------

local building = {
    maxHp             = 28000, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP022"] = building

----------------------

local building = {
    maxHp             = 37500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP023"] = building

----------------------

local building = {
    maxHp             = 37500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP024"] = building

----------------------

local building = {
    maxHp             = 48000, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP025"] = building

----------------------

local building = {
    maxHp             = 48000, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingP026"] = building

----------------------

local building = {
    maxHp             = 48000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingP027"] = building

----------------------

local building = {
    maxHp             = 48000, -- 最大 HP
    maxArmor          = 500,    -- 最大装甲
}
defines["BuildingP028"] = building

------------------------------------------------------------------
------------------------------------------------------------------

local building = {
    maxHp             = 3000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN001"] = building

----------------------

local building = {
    maxHp             = 3000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN002"] = building

----------------------

local building = {
    maxHp             = 3000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN003"] = building

----------------------

local building = {
    maxHp             = 3000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN004"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN005"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN006"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingN007"] = building

----------------------

local building = {
    maxHp             = 5500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingN008"] = building

----------------------

local building = {
    maxHp             = 8500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingN009"] = building

----------------------

local building = {
    maxHp             = 8500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingN010"] = building

----------------------

local building = {
    maxHp             = 8500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingN011"] = building

----------------------

local building = {
    maxHp             = 8500, -- 最大 HP
    maxArmor          = 0,     -- 最大装甲
}
defines["BuildingN012"] = building

----------------------

local building = {
    maxHp             = 13500, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN013"] = building

----------------------

local building = {
    maxHp             = 15500, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN014"] = building

----------------------
local building = {
    maxHp             = 24000, -- 最大 HP
    maxArmor          = 0,    -- 最大装甲
}
defines["BuildingN015"] = building

----------------------

local building = {
    maxHp             = 24000, -- 最大 HP
    maxArmor          = 50,    -- 最大装甲
}
defines["BuildingN016"] = building

----------------------

local building = {
    maxHp             = 30000, -- 最大 HP
    maxArmor          = 100,    -- 最大装甲
}
defines["BuildingN017"] = building

----------------------

local building = {
    maxHp             = 34000, -- 最大 HP
    maxArmor          = 150,    -- 最大装甲
}
defines["BuildingN018"] = building

----------------------

local building = {
    maxHp             = 40000, -- 最大 HP
    maxArmor          = 200,    -- 最大装甲
}
defines["BuildingN019"] = building

----------------------

local building = {
    maxHp             = 40000, -- 最大 HP
    maxArmor          = 250,    -- 最大装甲
}
defines["BuildingN020"] = building

----------------------

local building = {
    maxHp             = 38000, -- 最大 HP
    maxArmor          = 300,     -- 最大装甲
}
defines["BuildingN021"] = building

----------------------

local building = {
    maxHp             = 52000, -- 最大 HP
    maxArmor          = 450,     -- 最大装甲
}
defines["BuildingN022"] = building

----------------------

local building = {
    maxHp             = 47500, -- 最大 HP
    maxArmor          = 400,     -- 最大装甲
}
defines["BuildingN023"] = building

----------------------

local building = {
    maxHp             = 58000, -- 最大 HP
    maxArmor          = 450,     -- 最大装甲
}
defines["BuildingN024"] = building

----------------------

local building = {
    maxHp             = 48000, -- 最大 HP
    maxArmor          = 800,     -- 最大装甲
}
defines["BuildingN025"] = building

----------------------

local building = {
    maxHp             = 64000, -- 最大 HP
    maxArmor          = 800,     -- 最大装甲
}
defines["BuildingN026"] = building

----------------------

local building = {
    maxHp             = 50000, -- 最大 HP
    maxArmor          = 800,    -- 最大装甲
}
defines["BuildingN027"] = building

----------------------

local building = {
    maxHp             = 64000, -- 最大 HP
    maxArmor          = 800,    -- 最大装甲
}
defines["BuildingN028"] = building

------------------------------------------------------------------
------------------------------------------------------------------



function BuildingProperties.get(id)
    return clone(defines[id])
end

return BuildingProperties