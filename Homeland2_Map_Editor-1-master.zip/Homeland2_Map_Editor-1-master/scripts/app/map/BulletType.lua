
local BulletType = {}

BulletType.ARROW  = 1
BulletType.CANNON = 2

return BulletType
